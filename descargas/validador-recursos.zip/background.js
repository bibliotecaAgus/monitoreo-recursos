// Al pulsar el icono de la extensión se abre (o se enfoca) la página del validador.
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('validar.html');
  const [abierta] = await chrome.tabs.query({ url });
  if (abierta) {
    await chrome.tabs.update(abierta.id, { active: true });
    await chrome.windows.update(abierta.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});
