// Validador de recursos: abre cada recurso por el proxy institucional en una ventana aparte del
// Chrome del funcionario (con su sesión) y aplica las mismas reglas que el equipo de monitoreo
// (src/checkResource.ts): sin bucle ni tiempo de espera, dominio final esperado, texto esperado y
// sin "acceso denegado" ni pantalla de login. Al terminar envía los resultados a Apps Script.

/* global CONFIG */
const PROXY_HOST = 'itmsp.museknowledge.com';
const MAX_REDIRECCIONES = 20;
const TEXTOS_DENEGADO =
  /acceso denegado|access denied|unauthori[sz]ed|EXPIRED_LINK_STOP|SINGLE SIGN-ON: MISSING TARGET|no tiene acceso|not subscribed/i;
const BOTON_GOOGLE = /Iniciar sesión con Google/i;

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
const limpiarUrl = (url) => url.replace(/([?&](?:parentSessionId|sessionid|SAMLResponse|RelayState)=)[^&]*/gi, '$1…');

let recursos = [];
let detener = false;

/** El dominio final tal cual (www.proquest.com) o reescrito por el proxy (xxx-y-https-www-proquest-com.itmsp...). */
function coincideDominio(host, dominioFinal) {
  const esperado = dominioFinal.toLowerCase();
  host = host.toLowerCase();
  if (host === esperado) return true;
  return host.endsWith(`.${PROXY_HOST}`) && host.includes(esperado.replace(/\./g, '-'));
}

function esLogin(url, texto) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return false;
  }
  return u.host === 'accounts.google.com' || (u.host === PROXY_HOST && u.pathname.includes('/saml/discovery/')) || BOTON_GOOGLE.test(texto);
}

// ---------- Navegación en la ventana de validación ----------

let ventana = null;
let pestana = null;

async function abrirVentana() {
  ventana = await chrome.windows.create({ url: 'about:blank', focused: false, width: 1100, height: 760, left: 40, top: 40 });
  pestana = ventana.tabs[0].id;
}

async function cerrarVentana() {
  if (ventana) await chrome.windows.remove(ventana.id).catch(() => {});
  ventana = null;
}

/** Carga una URL y espera a que termine de redirigir. Devuelve { url, texto, error, navegaciones }. */
function cargar(url, timeoutMs) {
  return new Promise((resolve) => {
    let navegaciones = 0;
    let errorRed = null;
    let quieto = null;
    let terminado = false;
    const fin = (extra) => {
      if (terminado) return;
      terminado = true;
      clearTimeout(limite);
      clearTimeout(quieto);
      chrome.tabs.onUpdated.removeListener(alActualizar);
      chrome.webNavigation.onErrorOccurred.removeListener(alError);
      resolve({ navegaciones, ...extra });
    };
    // Cuando la pestaña lleva 2,5 s cargada sin cambiar de URL, se considera estable.
    const revisarEstable = () => {
      clearTimeout(quieto);
      quieto = setTimeout(async () => {
        const t = await chrome.tabs.get(pestana).catch(() => null);
        if (!t) return fin({ error: 'Se cerró la ventana de validación' });
        if (t.status !== 'complete') return revisarEstable();
        fin({ url: t.url });
      }, 2500);
    };
    const alActualizar = (id, cambio) => {
      if (id !== pestana) return;
      if (cambio.url) navegaciones++;
      if (navegaciones > MAX_REDIRECCIONES) return fin({ bucle: true });
      revisarEstable();
    };
    const alError = (d) => {
      if (d.tabId === pestana && d.frameId === 0 && !/ERR_ABORTED/.test(d.error)) {
        errorRed = d.error;
        if (/TOO_MANY_REDIRECTS/.test(d.error)) fin({ bucle: true });
        else fin({ error: `${d.error} en ${limpiarUrl(d.url)}` });
      }
    };
    const limite = setTimeout(() => fin({ timeout: true, error: errorRed }), timeoutMs);
    chrome.tabs.onUpdated.addListener(alActualizar);
    chrome.webNavigation.onErrorOccurred.addListener(alError);
    chrome.tabs.update(pestana, { url }).then(revisarEstable);
  });
}

async function leerPagina() {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: pestana },
      func: () => ({ url: location.href, texto: (document.body ? document.body.innerText : '').replace(/\s+/g, ' ') }),
    });
    return r.result;
  } catch {
    // Sin permiso sobre ese dominio (no es ninguno de los esperados) o página de error del navegador.
    const t = await chrome.tabs.get(pestana).catch(() => null);
    return { url: t ? t.url : '', texto: '' };
  }
}

async function pulsarBotonGoogle() {
  await chrome.scripting
    .executeScript({
      target: { tabId: pestana },
      func: () => {
        const b = [...document.querySelectorAll('a, button, div, span')].find((e) => /Iniciar sesión con Google/i.test(e.textContent || '') && e.children.length === 0);
        if (b) b.click();
        return Boolean(b);
      },
    })
    .catch(() => {});
}

// ---------- Validación ----------

async function validarRecurso(recurso) {
  const inicio = Date.now();
  const base = { nombre: recurso.nombre, fecha: new Date().toISOString() };
  const res = (tipo, error, url) => ({ ...base, ok: tipo === 'ok', tipo, error, urlFinal: limpiarUrl(url || ''), ms: Date.now() - inicio });

  const carga = await cargar(recurso.url_entrada, CONFIG.timeoutMs);
  if (carga.bucle) return res('bucle', `Más de ${MAX_REDIRECCIONES} redirecciones`);
  if (carga.timeout) return res('timeout', `Sin respuesta en ${CONFIG.timeoutMs} ms`);
  if (carga.error) return res('error', carga.error);

  const pagina = await leerPagina();
  if (esLogin(pagina.url, pagina.texto)) return res('sesion', 'Apareció la pantalla de login', pagina.url);

  let host = '';
  try {
    host = new URL(pagina.url).host;
  } catch {
    // URL no válida: cuenta como dominio inesperado
  }
  if (!coincideDominio(host, recurso.dominio_final)) {
    return res('dominio', `Dominio final ${host || 'desconocido'}, se esperaba ${recurso.dominio_final}`, pagina.url);
  }
  const denegado = pagina.texto.match(TEXTOS_DENEGADO);
  if (denegado) return res('denegado', `La página muestra "${denegado[0]}"`, pagina.url);
  const texto = pagina.texto.toLowerCase();
  const faltantes = recurso.texto_esperado.split('|').map((t) => t.trim()).filter((t) => t && !texto.includes(t.toLowerCase()));
  if (faltantes.length) return res('texto', `No aparece: ${faltantes.join(', ')}`, pagina.url);
  return res('ok', undefined, pagina.url);
}

/** Comprueba la sesión con el primer recurso; si el proxy pide login, intenta entrar con Google. */
async function asegurarSesion() {
  await cargar(recursos[0].url_entrada, CONFIG.timeoutMs);
  for (let intento = 0; intento < 2; intento++) {
    const p = await leerPagina();
    if (!esLogin(p.url, p.texto)) return true;
    if (p.url.startsWith('https://accounts.google.com')) return false;
    await pulsarBotonGoogle();
    await esperar(6000);
  }
  const p = await leerPagina();
  return !esLogin(p.url, p.texto);
}

async function validarTodo() {
  detener = false;
  $('inicio').hidden = true;
  $('fin').hidden = true;
  $('progreso').hidden = false;
  $('de').textContent = recursos.length;
  $('beats').replaceChildren(...recursos.map(() => el('span', 'beat')));
  const inicio = new Date();
  const resultados = [];

  await abrirVentana();
  try {
    $('actual').textContent = 'Comprobando la sesión institucional…';
    if (!(await asegurarSesion())) {
      await chrome.windows.update(ventana.id, { focused: true });
      ventana = null; // se deja abierta para que la persona inicie sesión
      return mostrarInicio('Inicia sesión con tu correo @uniagustiniana.edu.co en la ventana que se abrió y vuelve a pulsar "Validar recursos".', 'warn');
    }

    for (const [i, recurso] of recursos.entries()) {
      if (detener) break;
      $('actual').replaceChildren('Validando ', el('b', null, recurso.nombre));
      const r = await validarRecurso(recurso);
      resultados.push(r);
      $('beats').children[i].className = 'beat ' + (r.ok ? 'ok' : 'bad');
      $('beats').children[i].title = `${recurso.nombre}: ${r.ok ? 'disponible' : r.error}`;
      $('n').textContent = i + 1;
      $('barra').style.width = ((i + 1) / recursos.length) * 100 + '%';
      if (i < recursos.length - 1) await esperar(CONFIG.pausaMs);
    }
  } finally {
    await cerrarVentana();
  }

  if (detener) return mostrarInicio('Validación detenida. No se enviaron resultados.', 'warn');
  await mostrarFin(resultados, inicio);
}

async function mostrarFin(resultados, inicio) {
  $('progreso').hidden = true;
  $('fin').hidden = false;
  const fallan = resultados.filter((r) => !r.ok);
  $('r-ok').textContent = resultados.length - fallan.length;
  $('r-bad').textContent = fallan.length;
  $('r-min').textContent = Math.round((Date.now() - inicio.getTime()) / 60000) + ' min';
  $('fallas').replaceChildren(...fallan.map((r) => {
    const li = el('li');
    li.append(el('span', 'x', '✕'), el('span', null, r.nombre), el('small', null, r.error || ''));
    return li;
  }));
  $('ver').href = CONFIG.pagina;

  $('envio').replaceChildren(el('div', 'msg', 'Enviando resultados a la página de estado…'));
  try {
    const respuesta = await fetch(CONFIG.urlEnvio, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ fecha: inicio.toISOString(), login: true, resultados }),
    });
    const r = await respuesta.json();
    $('envio').replaceChildren(el('div', 'msg ' + (r.ok ? 'ok' : 'bad'), r.mensaje));
  } catch {
    $('envio').replaceChildren(el('div', 'msg bad', 'No se pudieron enviar los resultados. Revisa que tu sesión de Google sea la institucional y que tu correo esté autorizado.'));
  }
}

function mostrarInicio(mensaje, tipo) {
  $('progreso').hidden = true;
  $('inicio').hidden = false;
  $('aviso').replaceChildren(mensaje ? el('div', 'msg ' + tipo, mensaje) : '');
  $('btn-iniciar').disabled = recursos.length === 0;
}

// ---------- Inicio ----------

async function leerJson(url) {
  const r = await fetch(url + '?v=' + Date.now(), { cache: 'no-store' });
  if (!r.ok) throw new Error(r.status);
  return r.json();
}

/** Evita validar si el equipo de monitoreo ya está validando o si hubo una validación hace poco. */
async function revisarDisponibilidad() {
  const [ejecucion, historial] = await Promise.all([
    leerJson(CONFIG.pagina + 'datos/ejecucion.json').catch(() => null),
    leerJson(CONFIG.pagina + 'datos/historial.json').catch(() => []),
  ]);
  if (ejecucion && ejecucion.estado === 'en_curso' && Date.now() - Date.parse(ejecucion.inicio) < 2 * 3600e3) {
    return 'El equipo de monitoreo está validando en este momento. Revisa la página de estado en unos minutos.';
  }
  const ultima = historial.length ? Date.parse(historial[historial.length - 1].fecha) : 0;
  const minutos = (Date.now() - ultima) / 60000;
  if (minutos < CONFIG.esperaMinutos) {
    return `La última validación fue hace ${Math.floor(minutos)} min. Para cuidar los términos de uso de los proveedores, espera ${Math.ceil(CONFIG.esperaMinutos - minutos)} min.`;
  }
  return null;
}

async function iniciar() {
  try {
    recursos = await leerJson(CONFIG.pagina + 'recursos.json');
  } catch {
    return mostrarInicio('No se pudo cargar la lista de recursos. Revisa tu conexión a internet.', 'bad');
  }
  $('total').textContent = recursos.length;
  const bloqueo = await revisarDisponibilidad();
  mostrarInicio(bloqueo, 'warn');
  if (bloqueo) $('btn-iniciar').disabled = true;
}

$('btn-iniciar').addEventListener('click', () => validarTodo().catch((e) => mostrarInicio('La validación se interrumpió: ' + e.message, 'bad')));
$('btn-detener').addEventListener('click', () => {
  detener = true;
  $('actual').textContent = 'Deteniendo…';
});
iniciar();
