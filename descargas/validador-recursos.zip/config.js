// Generado por src/construirExtension.ts
const CONFIG = {
  "pagina": "https://bibliotecaagus.github.io/monitoreo-recursos/",
  "urlEnvio": "https://script.google.com/a/macros/uniagustiniana.edu.co/s/AKfycbwc_RA4Am-Mfytuh8tnijD4qHF0I7BNaXOn5ovK4clDDzjau7pzsPByKdGuBNQXJVEb/exec",
  "timeoutMs": 45000,
  "pausaMs": 4000,
  "esperaMinutos": 30
};
